export class Midterm {
  LASTdalmiac!: string;
  FIRSTdalmiac!: string;
  EMAILdalmiac!: string;
  PROGRAMNAMEdalmiac!: string;
  LOGINDalmiac!: string;
}
